
-- Fix some missing prerequisites which annoy me
table.insert(data.raw.technology["electronics"].prerequisites,"logistics")
