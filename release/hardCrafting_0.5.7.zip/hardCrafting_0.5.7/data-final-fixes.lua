require "libs.all"
require "libs.prototypes.prototypes"

require "prototypes.bigger-furnaces"
require "prototypes.incinerator-recipes"
require "prototypes.easier-but-more-trains"

require "prototypes.technology-fixes"
require "prototypes.productivity-support"

require "prototypes.harder-buildings"

require "prototypes.fixes-methane-processing"

-- Recipe categories tweaks
addCategorySupportsNew("pulverizer","hc-pulverizer")
addCategorySupportsNew("big-processing-machine","hc-pulverizer")

