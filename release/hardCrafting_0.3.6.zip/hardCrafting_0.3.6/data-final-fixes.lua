require "basic-lua-extensions"

require"prototypes.incinerator-recipes"
