require "basic-lua-extensions"
require "functions"

require "prototypes.incinerator-recipes"
require "prototypes.easier-but-more-trains"