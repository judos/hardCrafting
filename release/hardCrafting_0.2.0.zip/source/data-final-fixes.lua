require("basic-lua-extensions")

require("prototypes.incinerator-recipes")

-- integration with landfill mod
require("prototypes.landfill")