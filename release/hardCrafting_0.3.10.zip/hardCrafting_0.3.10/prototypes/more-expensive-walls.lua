require "libs.functions"

ChangeRecipe("stone-wall", "stone-brick", "stone-brick", 20)
data.raw["recipe"]["stone-wall"].energy_required = 2.5