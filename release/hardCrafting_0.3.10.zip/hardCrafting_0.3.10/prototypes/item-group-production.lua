data:extend({
  {
    type = "item-subgroup",
    name = "advanced-processing-machine",
    group = "production",
    order = "d1",
  },
})