require "libs.functions"

-- Required:
require "prototypes.bigger-mining-drills"

-- Features:
require "prototypes.more-expensive-walls"

-- Integration with recipes of other mods
require "prototypes.fluid-barrels"
require "prototypes.landfill"
require "prototypes.angel_ores_hardcrafting"
