require "libs.functions"

require "prototypes.bigger-furnaces"
require "prototypes.incinerator-recipes"
require "prototypes.easier-but-more-trains"