
modVersion = "0.4.0"
modName = "hc" -- required prefix for all ui name components which can be clicked
fullModName = "hardCrafting" -- required for logging and prototypes


libLog.testing = true