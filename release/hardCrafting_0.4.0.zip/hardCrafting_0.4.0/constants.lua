
modVersion = "0.4.0"
modName = "hc" -- required prefix for all ui name components which can be clicked
fullModName = "hardCrafting" -- required for logging and prototypes


local testing = true
if testing then
	debug_master = true -- Master switch for debugging, prints debug stuff into the shell where factorio was started from
	debug_level = 1 -- 1=info 2=warning 3=error
end
