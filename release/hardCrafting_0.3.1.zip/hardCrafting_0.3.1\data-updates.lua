require "functions"

-- Required:
require "prototypes.bigger-mining-drills"

-- Features: (can be disabled)
require "prototypes.harder-buildings"

-- Integration with recipes of other mods
require "prototypes.fluid-barrels"
require "prototypes.landfill"

