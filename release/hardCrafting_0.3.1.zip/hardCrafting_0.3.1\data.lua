require "basic-lua-extensions"
require "functions"

require "prototypes.fast-long-inserter"
require "prototypes.incinerator"
require "prototypes.electric-incinerator"
require "prototypes.harder-iron-processing"
require "prototypes.harder-copper-processing"
require "prototypes.harder-coal"
require "prototypes.steel-dust"

require "prototypes.easier-but-more-trains"

require("prototypes.engines-and-robots")
