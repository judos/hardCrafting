require "libs.prototypes.prototypes"

recipeReplaceIngredient("stone-wall", "stone-brick", "stone-brick", 10)
data.raw["recipe"]["stone-wall"].energy_required = 2.5