if settings.startup["hardcrafting-complex-crafting-byproduct"].value == true then


	-- Item: --
	addItem("scrap-metal","raw-resource","z[scrap-metal]",50)
	
end